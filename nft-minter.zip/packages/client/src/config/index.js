export default {
  infuraKey: process.env.REACT_APP_INFURA_API_KEY,
  gistId: process.env.REACT_APP_PREDEFINED_GITHUB_GIST_ID,
};
